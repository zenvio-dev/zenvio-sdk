import {
  NodeOperationError,
  type IExecuteFunctions,
  type IDataObject,
  type INode,
  type INodeExecutionData,
  type INodeType,
  type INodeTypeDescription,
} from 'n8n-workflow';
import { Notifique, NotifiqueApiError } from '@notifique/sdk-node';

type JsonRecord = Record<string, unknown>;

const WAITABLE_RESOURCES = new Set(['whatsapp', 'sms', 'email', 'pushMessages', 'templates']);

function toStringArray(value: string): string[] {
  return value
    .split(',')
    .map((item) => item.trim())
    .filter((item) => item.length > 0);
}

function parseJsonObject(raw: string): JsonRecord {
  if (!raw.trim()) return {};
  const parsed = JSON.parse(raw) as unknown;
  if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) {
    throw new Error('Valor JSON deve ser um objeto');
  }
  return parsed as JsonRecord;
}

function shouldConfirm(operation: string): boolean {
  return ['cancel', 'delete'].includes(operation);
}

async function sleep(ms: number): Promise<void> {
  await new Promise((resolve) => setTimeout(resolve, ms));
}

async function pollMessage<T>(
  getter: () => Promise<T>,
  pollIntervalMs: number,
  pollTimeoutMs: number,
  statusExtractor: (result: T) => string | undefined,
): Promise<{ final: T; timedOut: boolean; elapsedMs: number; status?: string }> {
  const start = Date.now();
  const finalStatuses = new Set(['SENT', 'DELIVERED', 'READ', 'FAILED', 'CANCELLED']);

  for (;;) {
    const result = await getter();
    const status = statusExtractor(result)?.toUpperCase();
    if (status && finalStatuses.has(status)) {
      return { final: result, timedOut: false, elapsedMs: Date.now() - start, status };
    }

    const elapsed = Date.now() - start;
    if (elapsed >= pollTimeoutMs) {
      return { final: result, timedOut: true, elapsedMs: elapsed, status };
    }
    await sleep(pollIntervalMs);
  }
}

function normalizeError(error: unknown): JsonRecord {
  if (error instanceof NotifiqueApiError) {
    return {
      name: error.name,
      message: error.message,
      statusCode: error.statusCode,
      code: error.code,
      responseData: error.responseData,
    };
  }
  if (error instanceof Error) return { name: error.name, message: error.message };
  return { message: String(error) };
}

function toNodeError(node: INode, error: unknown, itemIndex: number): NodeOperationError {
  if (error instanceof NotifiqueApiError) {
    const message = `Notifique API ${error.statusCode}: ${error.message}`;
    return new NodeOperationError(node, message, {
      itemIndex,
      description: JSON.stringify(
        { code: error.code, responseData: error.responseData },
        null,
        2,
      ),
    });
  }
  if (error instanceof Error) {
    return new NodeOperationError(node, error.message, { itemIndex });
  }
  return new NodeOperationError(node, String(error), { itemIndex });
}

export class NotifiqueNode implements INodeType {
  description: INodeTypeDescription = {
    displayName: 'Notifique',
    name: 'notifiqueNode',
    icon: 'file:notifique.svg',
    group: ['transform'],
    version: 1,
    subtitle: '={{$parameter["resource"] + " : " + $parameter["operation"]}}',
    description: 'Integração no-code da Notifique para n8n',
    defaults: {
      name: 'Notifique',
    },
    credentials: [
      {
        name: 'notifiqueApi',
        required: true,
      },
    ],
    inputs: ['main'],
    outputs: ['main'],
    properties: [
      {
        displayName: 'Recurso',
        name: 'resource',
        type: 'options',
        noDataExpression: true,
        default: 'whatsapp',
        options: [
          { name: 'WhatsApp Mensagens', value: 'whatsapp' },
          { name: 'WhatsApp Instâncias', value: 'whatsappInstances' },
          { name: 'WhatsApp Grupos', value: 'whatsappGroups' },
          { name: 'SMS', value: 'sms' },
          { name: 'Email', value: 'email' },
          { name: 'Templates', value: 'templates' },
          { name: 'Contatos', value: 'contacts' },
          { name: 'Tags', value: 'tags' },
          { name: 'Email Domains', value: 'emailDomains' },
          { name: 'Push Apps', value: 'pushApps' },
          { name: 'Push Devices', value: 'pushDevices' },
          { name: 'Push Messages', value: 'pushMessages' },
        ],
      },
      {
        displayName: 'Operação',
        name: 'operation',
        type: 'options',
        noDataExpression: true,
        default: 'sendText',
        displayOptions: { show: { resource: ['whatsapp'] } },
        options: [
          { name: 'Enviar Texto', value: 'sendText', action: 'Enviar texto no WhatsApp' },
          { name: 'Listar Mensagens', value: 'listMessages', action: 'Listar mensagens do WhatsApp' },
          { name: 'Buscar Mensagem', value: 'getMessage', action: 'Buscar status da mensagem WhatsApp' },
          { name: 'Editar Mensagem', value: 'edit', action: 'Editar mensagem já enviada' },
          { name: 'Cancelar Mensagem', value: 'cancel', action: 'Cancelar mensagem agendada' },
          { name: 'Excluir Mensagem', value: 'delete', action: 'Excluir mensagem para todos' },
        ],
      },
      {
        displayName: 'Operação',
        name: 'operation',
        type: 'options',
        noDataExpression: true,
        default: 'list',
        displayOptions: { show: { resource: ['whatsappInstances'] } },
        options: [
          { name: 'Listar', value: 'list', action: 'Listar instâncias WhatsApp' },
          { name: 'Criar', value: 'create', action: 'Criar instância WhatsApp' },
          { name: 'Buscar', value: 'get', action: 'Buscar instância WhatsApp' },
          { name: 'Obter QR Code', value: 'getQr', action: 'Obter QR code atual da instância' },
          { name: 'Desconectar', value: 'disconnect', action: 'Desconectar instância WhatsApp' },
          { name: 'Remover', value: 'delete', action: 'Remover instância WhatsApp' },
        ],
      },
      {
        displayName: 'Operação',
        name: 'operation',
        type: 'options',
        noDataExpression: true,
        default: 'list',
        displayOptions: { show: { resource: ['whatsappGroups'] } },
        options: [
          { name: 'Listar Grupos', value: 'list', action: 'Listar grupos da instância' },
          { name: 'Listar Participantes', value: 'listParticipants', action: 'Listar participantes do grupo' },
          { name: 'Adicionar Participantes', value: 'addParticipants', action: 'Adicionar participantes ao grupo' },
          { name: 'Remover Participantes', value: 'removeParticipants', action: 'Remover participantes do grupo' },
          { name: 'Enviar Link de Convite', value: 'sendInvite', action: 'Enviar convite do grupo' },
          { name: 'Revogar Link de Convite', value: 'revokeInvite', action: 'Revogar convite do grupo' },
          { name: 'Buscar Código de Convite', value: 'getInviteCode', action: 'Buscar código de convite do grupo' },
        ],
      },
      {
        displayName: 'Operação',
        name: 'operation',
        type: 'options',
        noDataExpression: true,
        default: 'send',
        displayOptions: { show: { resource: ['sms'] } },
        options: [
          { name: 'Enviar', value: 'send', action: 'Enviar SMS' },
          { name: 'Buscar', value: 'get', action: 'Buscar status do SMS' },
          { name: 'Cancelar', value: 'cancel', action: 'Cancelar SMS agendado' },
        ],
      },
      {
        displayName: 'Operação',
        name: 'operation',
        type: 'options',
        noDataExpression: true,
        default: 'send',
        displayOptions: { show: { resource: ['email'] } },
        options: [
          { name: 'Enviar', value: 'send', action: 'Enviar email' },
          { name: 'Buscar', value: 'get', action: 'Buscar status do email' },
          { name: 'Cancelar', value: 'cancel', action: 'Cancelar email agendado' },
        ],
      },
      {
        displayName: 'Operação',
        name: 'operation',
        type: 'options',
        noDataExpression: true,
        default: 'send',
        displayOptions: { show: { resource: ['templates'] } },
        options: [{ name: 'Enviar Template', value: 'send', action: 'Enviar template multicanal' }],
      },
      {
        displayName: 'Operação',
        name: 'operation',
        type: 'options',
        noDataExpression: true,
        default: 'list',
        displayOptions: { show: { resource: ['contacts'] } },
        options: [
          { name: 'Listar', value: 'list', action: 'Listar contatos' },
          { name: 'Criar', value: 'create', action: 'Criar contato' },
          { name: 'Buscar', value: 'get', action: 'Buscar contato' },
          { name: 'Atualizar', value: 'update', action: 'Atualizar contato' },
          { name: 'Excluir', value: 'delete', action: 'Excluir contato' },
        ],
      },
      {
        displayName: 'Operação',
        name: 'operation',
        type: 'options',
        noDataExpression: true,
        default: 'list',
        displayOptions: { show: { resource: ['tags'] } },
        options: [
          { name: 'Listar', value: 'list', action: 'Listar tags' },
          { name: 'Criar', value: 'create', action: 'Criar tag' },
          { name: 'Buscar', value: 'get', action: 'Buscar tag' },
          { name: 'Atualizar', value: 'update', action: 'Atualizar tag' },
          { name: 'Excluir', value: 'delete', action: 'Excluir tag' },
        ],
      },
      {
        displayName: 'Operação',
        name: 'operation',
        type: 'options',
        noDataExpression: true,
        default: 'list',
        displayOptions: { show: { resource: ['emailDomains'] } },
        options: [
          { name: 'Listar', value: 'list', action: 'Listar domínios de email' },
          { name: 'Criar', value: 'create', action: 'Criar domínio de email' },
          { name: 'Buscar', value: 'get', action: 'Buscar domínio por ID' },
          { name: 'Verificar DNS', value: 'verify', action: 'Verificar domínio de email' },
        ],
      },
      {
        displayName: 'Operação',
        name: 'operation',
        type: 'options',
        noDataExpression: true,
        default: 'list',
        displayOptions: { show: { resource: ['pushApps'] } },
        options: [
          { name: 'Listar', value: 'list', action: 'Listar apps de push' },
          { name: 'Criar', value: 'create', action: 'Criar app de push' },
          { name: 'Buscar', value: 'get', action: 'Buscar app de push' },
          { name: 'Atualizar', value: 'update', action: 'Atualizar app de push' },
          { name: 'Excluir', value: 'delete', action: 'Excluir app de push' },
        ],
      },
      {
        displayName: 'Operação',
        name: 'operation',
        type: 'options',
        noDataExpression: true,
        default: 'register',
        displayOptions: { show: { resource: ['pushDevices'] } },
        options: [
          { name: 'Registrar', value: 'register', action: 'Registrar device de push' },
          { name: 'Listar', value: 'list', action: 'Listar devices de push' },
          { name: 'Buscar', value: 'get', action: 'Buscar device de push' },
          { name: 'Excluir', value: 'delete', action: 'Excluir device de push' },
        ],
      },
      {
        displayName: 'Operação',
        name: 'operation',
        type: 'options',
        noDataExpression: true,
        default: 'send',
        displayOptions: { show: { resource: ['pushMessages'] } },
        options: [
          { name: 'Enviar', value: 'send', action: 'Enviar push message' },
          { name: 'Listar', value: 'list', action: 'Listar push messages' },
          { name: 'Buscar', value: 'get', action: 'Buscar push message' },
          { name: 'Cancelar', value: 'cancel', action: 'Cancelar push message' },
        ],
      },

      { displayName: 'ID da Instância', name: 'instanceId', type: 'string', default: '', displayOptions: { show: { resource: ['whatsapp', 'whatsappInstances', 'whatsappGroups'], operation: ['sendText', 'get', 'getQr', 'disconnect', 'delete', 'list', 'listParticipants', 'addParticipants', 'removeParticipants', 'sendInvite', 'revokeInvite', 'getInviteCode'] } } },
      { displayName: 'Para (número ou lista separada por vírgula)', name: 'to', type: 'string', default: '', displayOptions: { show: { resource: ['whatsapp', 'sms', 'email', 'templates', 'whatsappGroups'], operation: ['sendText', 'send', 'sendInvite'] } } },
      { displayName: 'Mensagem', name: 'message', type: 'string', typeOptions: { rows: 3 }, default: '', displayOptions: { show: { resource: ['whatsapp', 'sms'], operation: ['sendText', 'send'] } } },
      { displayName: 'ID da Mensagem', name: 'messageId', type: 'string', default: '', displayOptions: { show: { resource: ['whatsapp'], operation: ['getMessage', 'cancel', 'delete', 'edit'] } } },
      { displayName: 'Novo Texto da Mensagem', name: 'editedText', type: 'string', default: '', displayOptions: { show: { resource: ['whatsapp'], operation: ['edit'] } } },
      { displayName: 'Filtros de Mensagens (JSON)', name: 'whatsappListParamsJson', type: 'json', default: '{}', displayOptions: { show: { resource: ['whatsapp'], operation: ['listMessages'] } } },
      { displayName: 'Nome da Instância', name: 'instanceName', type: 'string', default: '', displayOptions: { show: { resource: ['whatsappInstances'], operation: ['create'] } } },
      { displayName: 'ID do Grupo', name: 'groupId', type: 'string', default: '', displayOptions: { show: { resource: ['whatsappGroups'], operation: ['listParticipants'] } } },
      { displayName: 'Group JID', name: 'groupJid', type: 'string', default: '', displayOptions: { show: { resource: ['whatsappGroups'], operation: ['addParticipants', 'removeParticipants', 'revokeInvite', 'getInviteCode'] } } },
      { displayName: 'Grupos (JIDs separados por vírgula)', name: 'groupJidsCsv', type: 'string', default: '', displayOptions: { show: { resource: ['whatsappGroups'], operation: ['sendInvite'] } } },
      { displayName: 'Participantes (números/JIDs separados por vírgula)', name: 'participantsCsv', type: 'string', default: '', displayOptions: { show: { resource: ['whatsappGroups'], operation: ['addParticipants', 'removeParticipants'] } } },
      { displayName: 'Descrição do Convite', name: 'inviteDescription', type: 'string', default: 'Convite para o grupo', displayOptions: { show: { resource: ['whatsappGroups'], operation: ['sendInvite'] } } },
      { displayName: 'ID do SMS', name: 'smsId', type: 'string', default: '', displayOptions: { show: { resource: ['sms'], operation: ['get', 'cancel'] } } },
      { displayName: 'ID do Email', name: 'emailId', type: 'string', default: '', displayOptions: { show: { resource: ['email'], operation: ['get', 'cancel'] } } },
      { displayName: 'Remetente (from)', name: 'from', type: 'string', default: '', displayOptions: { show: { resource: ['email', 'templates'], operation: ['send'] } } },
      { displayName: 'Nome do Remetente', name: 'fromName', type: 'string', default: '', displayOptions: { show: { resource: ['email', 'templates'], operation: ['send'] } } },
      { displayName: 'Assunto', name: 'subject', type: 'string', default: '', displayOptions: { show: { resource: ['email'], operation: ['send'] } } },
      { displayName: 'Texto', name: 'text', type: 'string', typeOptions: { rows: 3 }, default: '', displayOptions: { show: { resource: ['email'], operation: ['send'] } } },
      { displayName: 'HTML', name: 'html', type: 'string', typeOptions: { rows: 3 }, default: '', displayOptions: { show: { resource: ['email'], operation: ['send'] } } },

      { displayName: 'Template', name: 'template', type: 'string', default: '', displayOptions: { show: { resource: ['templates'], operation: ['send'] } } },
      {
        displayName: 'Canais',
        name: 'channels',
        type: 'multiOptions',
        default: ['whatsapp'],
        options: [
          { name: 'WhatsApp', value: 'whatsapp' },
          { name: 'SMS', value: 'sms' },
          { name: 'Email', value: 'email' },
        ],
        displayOptions: { show: { resource: ['templates'], operation: ['send'] } },
      },
      {
        displayName: 'Variáveis (JSON)',
        name: 'variablesJson',
        type: 'json',
        default: '{}',
        displayOptions: { show: { resource: ['templates'], operation: ['send'] } },
      },
      { displayName: 'ID do Contato', name: 'contactId', type: 'string', default: '', displayOptions: { show: { resource: ['contacts'], operation: ['get', 'update', 'delete'] } } },
      { displayName: 'Payload do Contato (JSON)', name: 'contactPayloadJson', type: 'json', default: '{"name":"","phone":"","email":"","url":"","receiveMarketing":true,"tagIds":[]}', displayOptions: { show: { resource: ['contacts'], operation: ['create', 'update'] } } },
      { displayName: 'Filtros de Contato (JSON)', name: 'contactFiltersJson', type: 'json', default: '{}', displayOptions: { show: { resource: ['contacts'], operation: ['list'] } } },
      { displayName: 'ID da Tag', name: 'tagId', type: 'string', default: '', displayOptions: { show: { resource: ['tags'], operation: ['get', 'update', 'delete'] } } },
      { displayName: 'Nome da Tag', name: 'tagName', type: 'string', default: '', displayOptions: { show: { resource: ['tags'], operation: ['create', 'update'] } } },

      { displayName: 'ID do Domínio', name: 'domainId', type: 'string', default: '', displayOptions: { show: { resource: ['emailDomains'], operation: ['get', 'verify'] } } },
      { displayName: 'Domínio', name: 'domain', type: 'string', default: '', displayOptions: { show: { resource: ['emailDomains'], operation: ['create'] } } },

      { displayName: 'ID do App', name: 'appId', type: 'string', default: '', displayOptions: { show: { resource: ['pushApps'], operation: ['get', 'update', 'delete'] } } },
      { displayName: 'Nome do App', name: 'appName', type: 'string', default: '', displayOptions: { show: { resource: ['pushApps'], operation: ['create', 'update'] } } },
      {
        displayName: 'Dados de Update (JSON)',
        name: 'appUpdateJson',
        type: 'json',
        default: '{}',
        displayOptions: { show: { resource: ['pushApps'], operation: ['update'] } },
      },

      { displayName: 'ID do Device', name: 'deviceId', type: 'string', default: '', displayOptions: { show: { resource: ['pushDevices'], operation: ['get', 'delete'] } } },
      {
        displayName: 'Payload de Registro (JSON)',
        name: 'devicePayloadJson',
        type: 'json',
        default: '{"appId":"","platform":"web","token":""}',
        displayOptions: { show: { resource: ['pushDevices'], operation: ['register'] } },
      },
      {
        displayName: 'Filtros de Listagem (JSON)',
        name: 'listFiltersJson',
        type: 'json',
        default: '{}',
        displayOptions: { show: { resource: ['pushApps', 'pushDevices', 'pushMessages'], operation: ['list'] } },
      },

      {
        displayName: 'Payload do Push (JSON)',
        name: 'pushPayloadJson',
        type: 'json',
        default: '{"appId":"","title":"","body":"","deviceIds":[]}',
        displayOptions: { show: { resource: ['pushMessages'], operation: ['send'] } },
      },
      { displayName: 'ID da Push Message', name: 'pushMessageId', type: 'string', default: '', displayOptions: { show: { resource: ['pushMessages'], operation: ['get', 'cancel'] } } },

      {
        displayName: 'Idempotency Key',
        name: 'idempotencyKey',
        type: 'string',
        default: '',
        description: 'Chave opcional para retries idempotentes',
        displayOptions: {
          show: {
            resource: ['whatsapp', 'sms', 'email', 'pushMessages'],
            operation: ['sendText', 'send'],
          },
        },
      },
      {
        displayName: 'Aguardar Status Final',
        name: 'waitForStatus',
        type: 'boolean',
        default: false,
        description: 'Faz polling até status final quando aplicável',
        displayOptions: {
          show: {
            resource: ['whatsapp', 'sms', 'email', 'pushMessages', 'templates'],
            operation: ['sendText', 'send'],
          },
        },
      },
      {
        displayName: 'Intervalo de Polling (ms)',
        name: 'pollIntervalMs',
        type: 'number',
        typeOptions: { minValue: 500 },
        default: 2000,
        displayOptions: {
          show: {
            waitForStatus: [true],
            resource: ['whatsapp', 'sms', 'email', 'pushMessages', 'templates'],
            operation: ['sendText', 'send'],
          },
        },
      },
      {
        displayName: 'Timeout de Polling (ms)',
        name: 'pollTimeoutMs',
        type: 'number',
        typeOptions: { minValue: 2000 },
        default: 45000,
        displayOptions: {
          show: {
            waitForStatus: [true],
            resource: ['whatsapp', 'sms', 'email', 'pushMessages', 'templates'],
            operation: ['sendText', 'send'],
          },
        },
      },
      {
        displayName: 'Confirmo operação sensível',
        name: 'confirmSensitive',
        type: 'boolean',
        default: false,
        description: 'Obrigatório para cancel/delete',
        displayOptions: {
          show: {
            operation: ['cancel', 'delete'],
          },
        },
      },
    ],
  };

  async execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]> {
    const items = this.getInputData();
    const out: INodeExecutionData[] = [];

    for (let i = 0; i < items.length; i += 1) {
      try {
        const credentials = await this.getCredentials('notifiqueApi', i);
        const apiKey = String(credentials.apiKey ?? '');
        const baseUrl = String(credentials.baseUrl ?? 'https://api.notifique.dev/v1');
        const notifique = new Notifique({ apiKey, baseUrl });
        const rawClient = notifique.getClient();

        const resource = this.getNodeParameter('resource', i) as string;
        const operation = this.getNodeParameter('operation', i) as string;
        const idempotencyKey = this.getNodeParameter('idempotencyKey', i, '') as string;
        const waitForStatus = WAITABLE_RESOURCES.has(resource)
          ? (this.getNodeParameter('waitForStatus', i, false) as boolean)
          : false;
        const pollIntervalMs = this.getNodeParameter('pollIntervalMs', i, 2000) as number;
        const pollTimeoutMs = this.getNodeParameter('pollTimeoutMs', i, 45000) as number;

        if (shouldConfirm(operation)) {
          const confirmed = this.getNodeParameter('confirmSensitive', i, false) as boolean;
          if (!confirmed) {
            throw new NodeOperationError(
              this.getNode(),
              'Operação sensível bloqueada. Marque "Confirmo operação sensível" para continuar.',
              { itemIndex: i },
            );
          }
        }

        let response: unknown;

        if (resource === 'whatsapp') {
          if (operation === 'sendText') {
            const instanceId = this.getNodeParameter('instanceId', i) as string;
            const to = toStringArray(this.getNodeParameter('to', i) as string);
            const message = this.getNodeParameter('message', i) as string;
            response = await notifique.whatsapp.sendText(
              instanceId,
              to,
              message,
              idempotencyKey ? { idempotencyKey } : undefined,
            );

            if (waitForStatus) {
              const firstMessageId = (response as { data?: { messageIds?: string[] } }).data?.messageIds?.[0];
              if (firstMessageId) {
                response = await pollMessage(
                  async () => notifique.whatsapp.getMessage(firstMessageId),
                  pollIntervalMs,
                  pollTimeoutMs,
                  (r: unknown) => (r as { data?: { status?: string } }).data?.status,
                );
              }
            }
          } else if (operation === 'listMessages') {
            const params = parseJsonObject(this.getNodeParameter('whatsappListParamsJson', i, '{}') as string);
            response = await notifique.whatsapp.listMessages(params as never);
          } else if (operation === 'getMessage') {
            const messageId = this.getNodeParameter('messageId', i) as string;
            response = await notifique.whatsapp.getMessage(messageId);
          } else if (operation === 'edit') {
            const messageId = this.getNodeParameter('messageId', i) as string;
            const editedText = this.getNodeParameter('editedText', i) as string;
            response = await notifique.whatsapp.editMessage(messageId, { text: editedText });
          } else if (operation === 'cancel') {
            const messageId = this.getNodeParameter('messageId', i) as string;
            response = await notifique.whatsapp.cancelMessage(messageId);
          } else if (operation === 'delete') {
            const messageId = this.getNodeParameter('messageId', i) as string;
            response = await notifique.whatsapp.deleteMessage(messageId);
          }
        } else if (resource === 'whatsappInstances') {
          if (operation === 'list') {
            response = await notifique.whatsapp.listInstances();
          }
          if (operation === 'create') {
            const instanceName = this.getNodeParameter('instanceName', i) as string;
            response = await notifique.whatsapp.createInstance({ name: instanceName } as never);
          }
          if (operation === 'get') {
            const instanceId = this.getNodeParameter('instanceId', i) as string;
            response = await notifique.whatsapp.getInstance(instanceId);
          }
          if (operation === 'getQr') {
            const instanceId = this.getNodeParameter('instanceId', i) as string;
            response = await notifique.whatsapp.getInstanceQr(instanceId);
          }
          if (operation === 'disconnect') {
            const instanceId = this.getNodeParameter('instanceId', i) as string;
            response = await notifique.whatsapp.disconnectInstance(instanceId);
          }
          if (operation === 'delete') {
            const instanceId = this.getNodeParameter('instanceId', i) as string;
            response = await notifique.whatsapp.deleteInstance(instanceId);
          }
        } else if (resource === 'whatsappGroups') {
          const instanceId = this.getNodeParameter('instanceId', i) as string;
          if (operation === 'list') {
            response = (await rawClient.get(`/whatsapp/instances/${instanceId}/groups`)).data;
          }
          if (operation === 'listParticipants') {
            const groupId = this.getNodeParameter('groupId', i) as string;
            response = (await rawClient.get(`/whatsapp/instances/${instanceId}/groups/${groupId}/participants`)).data;
          }
          if (operation === 'addParticipants' || operation === 'removeParticipants') {
            const groupJid = this.getNodeParameter('groupJid', i) as string;
            const participants = toStringArray(this.getNodeParameter('participantsCsv', i) as string);
            response = (await rawClient.post(`/whatsapp/instances/${instanceId}/groups/participants`, {
              groupJid,
              action: operation === 'addParticipants' ? 'add' : 'remove',
              participants,
            })).data;
          }
          if (operation === 'sendInvite') {
            const groupJids = toStringArray(this.getNodeParameter('groupJidsCsv', i) as string);
            const to = toStringArray(this.getNodeParameter('to', i) as string);
            const description = this.getNodeParameter('inviteDescription', i, 'Convite para o grupo') as string;
            response = (await rawClient.post(`/whatsapp/instances/${instanceId}/groups/invite`, {
              groups: groupJids,
              to,
              description,
            })).data;
          }
          if (operation === 'revokeInvite') {
            const groupJid = this.getNodeParameter('groupJid', i) as string;
            response = (await rawClient.post(`/whatsapp/instances/${instanceId}/groups/invite/revoke`, { groupJid })).data;
          }
          if (operation === 'getInviteCode') {
            const groupJid = this.getNodeParameter('groupJid', i) as string;
            response = (await rawClient.get(`/whatsapp/instances/${instanceId}/groups/invite-code`, { params: { groupJid } })).data;
          }
        } else if (resource === 'sms') {
          if (operation === 'send') {
            const to = toStringArray(this.getNodeParameter('to', i) as string);
            const message = this.getNodeParameter('message', i) as string;
            response = await notifique.sms.send(
              { to, message },
              idempotencyKey ? { idempotencyKey } : undefined,
            );

            if (waitForStatus) {
              const firstSmsId = (response as { data?: { smsIds?: string[] } }).data?.smsIds?.[0];
              if (firstSmsId) {
                response = await pollMessage(
                  async () => notifique.sms.get(firstSmsId),
                  pollIntervalMs,
                  pollTimeoutMs,
                  (r: unknown) => (r as { data?: { status?: string } }).data?.status,
                );
              }
            }
          } else if (operation === 'get') {
            const smsId = this.getNodeParameter('smsId', i) as string;
            response = await notifique.sms.get(smsId);
          } else if (operation === 'cancel') {
            const smsId = this.getNodeParameter('smsId', i) as string;
            response = await notifique.sms.cancel(smsId);
          }
        } else if (resource === 'email') {
          if (operation === 'send') {
            const to = toStringArray(this.getNodeParameter('to', i) as string);
            const from = this.getNodeParameter('from', i) as string;
            const fromName = this.getNodeParameter('fromName', i, '') as string;
            const subject = this.getNodeParameter('subject', i) as string;
            const text = this.getNodeParameter('text', i, '') as string;
            const html = this.getNodeParameter('html', i, '') as string;
            const payload: JsonRecord = { to, from, subject };
            if (fromName) payload.fromName = fromName;
            if (text) payload.text = text;
            if (html) payload.html = html;
            response = await notifique.email.send(
              payload as never,
              idempotencyKey ? { idempotencyKey } : undefined,
            );
            if (waitForStatus) {
              const firstEmailId = (response as { data?: { emailIds?: string[] } }).data?.emailIds?.[0];
              if (firstEmailId) {
                response = await pollMessage(
                  async () => notifique.email.get(firstEmailId),
                  pollIntervalMs,
                  pollTimeoutMs,
                  (r: unknown) => (r as { data?: { status?: string } }).data?.status,
                );
              }
            }
          } else if (operation === 'get') {
            const emailId = this.getNodeParameter('emailId', i) as string;
            response = await notifique.email.get(emailId);
          } else if (operation === 'cancel') {
            const emailId = this.getNodeParameter('emailId', i) as string;
            response = await notifique.email.cancel(emailId);
          }
        } else if (resource === 'templates') {
          const to = toStringArray(this.getNodeParameter('to', i) as string);
          const template = this.getNodeParameter('template', i) as string;
          const channels = this.getNodeParameter('channels', i) as string[];
          const variables = parseJsonObject(this.getNodeParameter('variablesJson', i, '{}') as string);
          const from = this.getNodeParameter('from', i, '') as string;
          const fromName = this.getNodeParameter('fromName', i, '') as string;
          const instanceId = this.getNodeParameter('instanceId', i, '') as string;
          const payload: JsonRecord = { to, template, channels };
          if (Object.keys(variables).length > 0) payload.variables = variables;
          if (from) payload.from = from;
          if (fromName) payload.fromName = fromName;
          if (instanceId) payload.instanceId = instanceId;
          response = await notifique.messages.send(payload as never);

          if (waitForStatus) {
            const sendData = (response as { data?: JsonRecord }).data ?? {};
            const statuses: JsonRecord = {};
            const messageIds = (sendData.messageIds as string[] | undefined) ?? [];
            const smsIds = (sendData.smsIds as string[] | undefined) ?? [];
            const emailIds = (sendData.emailIds as string[] | undefined) ?? [];
            if (messageIds[0]) statuses.whatsapp = await pollMessage(async () => notifique.whatsapp.getMessage(messageIds[0]), pollIntervalMs, pollTimeoutMs, (r: unknown) => (r as { data?: { status?: string } }).data?.status);
            if (smsIds[0]) statuses.sms = await pollMessage(async () => notifique.sms.get(smsIds[0]), pollIntervalMs, pollTimeoutMs, (r: unknown) => (r as { data?: { status?: string } }).data?.status);
            if (emailIds[0]) statuses.email = await pollMessage(async () => notifique.email.get(emailIds[0]), pollIntervalMs, pollTimeoutMs, (r: unknown) => (r as { data?: { status?: string } }).data?.status);
            response = { send: response, status: statuses };
          }
        } else if (resource === 'contacts') {
          if (operation === 'list') {
            const filters = parseJsonObject(this.getNodeParameter('contactFiltersJson', i, '{}') as string);
            response = (await rawClient.get('/contacts', { params: filters })).data;
          }
          if (operation === 'create') {
            const payload = parseJsonObject(this.getNodeParameter('contactPayloadJson', i) as string);
            response = (await rawClient.post('/contacts', payload)).data;
          }
          if (operation === 'get') {
            const contactId = this.getNodeParameter('contactId', i) as string;
            response = (await rawClient.get(`/contacts/${contactId}`)).data;
          }
          if (operation === 'update') {
            const contactId = this.getNodeParameter('contactId', i) as string;
            const payload = parseJsonObject(this.getNodeParameter('contactPayloadJson', i) as string);
            response = (await rawClient.put(`/contacts/${contactId}`, payload)).data;
          }
          if (operation === 'delete') {
            const contactId = this.getNodeParameter('contactId', i) as string;
            response = (await rawClient.delete(`/contacts/${contactId}`)).data;
          }
        } else if (resource === 'tags') {
          if (operation === 'list') {
            response = (await rawClient.get('/tags')).data;
          }
          if (operation === 'create') {
            const tagName = this.getNodeParameter('tagName', i) as string;
            response = (await rawClient.post('/tags', { name: tagName })).data;
          }
          if (operation === 'get') {
            const tagId = this.getNodeParameter('tagId', i) as string;
            response = (await rawClient.get(`/tags/${tagId}`)).data;
          }
          if (operation === 'update') {
            const tagId = this.getNodeParameter('tagId', i) as string;
            const tagName = this.getNodeParameter('tagName', i) as string;
            response = (await rawClient.put(`/tags/${tagId}`, { name: tagName })).data;
          }
          if (operation === 'delete') {
            const tagId = this.getNodeParameter('tagId', i) as string;
            response = (await rawClient.delete(`/tags/${tagId}`)).data;
          }
        } else if (resource === 'emailDomains') {
          if (operation === 'list') response = await notifique.email.domains.list();
          if (operation === 'create') {
            const domain = this.getNodeParameter('domain', i) as string;
            response = await notifique.email.domains.create({ domain });
          }
          if (operation === 'get') {
            const domainId = this.getNodeParameter('domainId', i) as string;
            response = await notifique.email.domains.get(domainId);
          }
          if (operation === 'verify') {
            const domainId = this.getNodeParameter('domainId', i) as string;
            response = await notifique.email.domains.verify(domainId);
          }
        } else if (resource === 'pushApps') {
          if (operation === 'list') {
            const filters = parseJsonObject(this.getNodeParameter('listFiltersJson', i, '{}') as string);
            response = await notifique.push.apps.list(filters as never);
          }
          if (operation === 'create') {
            const appName = this.getNodeParameter('appName', i) as string;
            response = await notifique.push.apps.create({ name: appName });
          }
          if (operation === 'get') {
            const appId = this.getNodeParameter('appId', i) as string;
            response = await notifique.push.apps.get(appId);
          }
          if (operation === 'update') {
            const appId = this.getNodeParameter('appId', i) as string;
            const appName = this.getNodeParameter('appName', i, '') as string;
            const patch = parseJsonObject(this.getNodeParameter('appUpdateJson', i, '{}') as string);
            if (appName) patch.name = appName;
            response = await notifique.push.apps.update(appId, patch as never);
          }
          if (operation === 'delete') {
            const appId = this.getNodeParameter('appId', i) as string;
            response = await notifique.push.apps.delete(appId);
          }
        } else if (resource === 'pushDevices') {
          if (operation === 'register') {
            const payload = parseJsonObject(this.getNodeParameter('devicePayloadJson', i) as string);
            response = await notifique.push.devices.register(payload as never);
          }
          if (operation === 'list') {
            const filters = parseJsonObject(this.getNodeParameter('listFiltersJson', i, '{}') as string);
            response = await notifique.push.devices.list(filters as never);
          }
          if (operation === 'get') {
            const deviceId = this.getNodeParameter('deviceId', i) as string;
            response = await notifique.push.devices.get(deviceId);
          }
          if (operation === 'delete') {
            const deviceId = this.getNodeParameter('deviceId', i) as string;
            response = await notifique.push.devices.delete(deviceId);
          }
        } else if (resource === 'pushMessages') {
          if (operation === 'send') {
            const payload = parseJsonObject(this.getNodeParameter('pushPayloadJson', i) as string);
            response = await notifique.push.messages.send(
              payload as never,
              idempotencyKey ? { idempotencyKey } : undefined,
            );
            if (waitForStatus) {
              const firstMessageId = (response as { data?: { id?: string } }).data?.id;
              if (firstMessageId) {
                response = await pollMessage(
                  async () => notifique.push.messages.get(firstMessageId),
                  pollIntervalMs,
                  pollTimeoutMs,
                  (r: unknown) => (r as { data?: { status?: string } }).data?.status,
                );
              }
            }
          }
          if (operation === 'list') {
            const filters = parseJsonObject(this.getNodeParameter('listFiltersJson', i, '{}') as string);
            response = await notifique.push.messages.list(filters as never);
          }
          if (operation === 'get') {
            const pushMessageId = this.getNodeParameter('pushMessageId', i) as string;
            response = await notifique.push.messages.get(pushMessageId);
          }
          if (operation === 'cancel') {
            const pushMessageId = this.getNodeParameter('pushMessageId', i) as string;
            response = await notifique.push.messages.cancel(pushMessageId);
          }
        }

        out.push({ json: (response ?? {}) as IDataObject, pairedItem: { item: i } });
      } catch (error) {
        if (this.continueOnFail()) {
          out.push({
            json: {
              success: false,
              error: normalizeError(error) as IDataObject,
            },
            pairedItem: { item: i },
          });
          continue;
        }
        throw toNodeError(this.getNode(), error, i);
      }
    }

    return [out];
  }

}
