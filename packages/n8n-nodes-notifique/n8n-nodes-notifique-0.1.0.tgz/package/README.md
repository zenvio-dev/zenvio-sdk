# n8n-nodes-notifique

Node comunitário do n8n para usar a Notifique sem código.

## Recursos disponíveis

- WhatsApp: enviar texto, buscar status, cancelar, excluir
- WhatsApp (mensagens): listar, enviar, status, editar, apagar, cancelar
- WhatsApp (grupos): listar grupos, listar participantes, adicionar/remover participantes, enviar/revogar convite, buscar código de convite
- WhatsApp (instâncias): listar, criar, buscar, remover, obter QR, desconectar
- SMS: enviar, buscar, cancelar
- Email: enviar, buscar, cancelar
- Templates: envio multicanal
- Contatos: listar, criar, buscar, atualizar, excluir
- Tags: listar, criar, buscar, atualizar, excluir
- Email Domains: listar, criar, buscar, verificar
- Push Apps: listar, criar, buscar, atualizar, excluir
- Push Devices: registrar, listar, buscar, excluir
- Push Messages: enviar, listar, buscar, cancelar

## Instalação

No n8n self-host:

```bash
npm install n8n-nodes-notifique
```

## Credenciais

Crie a credencial `Notifique API` com:

- `API Key`: chave da Notifique
- `Base URL`: opcional (default: `https://api.notifique.dev/v1`)

## Recursos de confiabilidade

- `Idempotency Key` para envios (WhatsApp/SMS/Email/Push)
- `Aguardar Status Final` com polling opcional
- bloqueio de operações sensíveis (`cancel`/`delete`) via confirmação explícita

## Templates prontos

Exemplos em `templates/`:

- `whatsapp-from-webhook.json`
- `payment-failure-multichannel.json`

